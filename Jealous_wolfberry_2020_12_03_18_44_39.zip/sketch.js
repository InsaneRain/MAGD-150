let img;
let c;
let imgAlien;
let  fontBrickTown;

function preload() {
  // preload() runs once
  img = loadImage('Pics/galaga.png');
  imgAlien = loadImage('Pics/alien.png');
  fontBrickTown = loadFont('Pics/Bricktown.ttf');
}


function setup() {
  createCanvas(400, 400); 
  // setup() waits until preload() is done
  img.loadPixels();
  imgAlien.loadPixels();
  // get color of middle pixel
  c = img.get(img.width / 2, img.height / 2);
}

function draw() {
  background(200);
  image(img, mouseX-50, 300, 100, 100);
  image(imgAlien, 150, mouseY-20, 70, 50);
  
fill(0)
  .strokeWeight(0) 
textFont(fontBrickTown);
textSize(20);
text('Space Invaders', 110, 30);
  
  
fill(0)
  .strokeWeight(0) 
textSize(10);
text('Coming soon...', 150, 50);
}